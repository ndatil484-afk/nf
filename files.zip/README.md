# Personal Portfolio

A minimal designer portfolio — clean, fast, and zero dependencies.

## 🚀 Quick Start

Clone and open `index.html` in any browser. No build step needed.

```bash
git clone https://github.com/yourname/portfolio.git
cd portfolio
open index.html
```

## 📁 Structure

```
portfolio/
├── index.html    # Main page
├── style.css     # All styles
├── script.js     # Scroll animations
└── README.md
```

## ✏️ Customize

1. **`index.html`** — Replace all `Your Name`, email, and social links
2. **Project cards** — Update title, description, and `project-img` background colors
3. **Skills** — Edit the three skill groups in the Skills section
4. **Fonts** — Swap Google Fonts link in `<head>` if desired

## 🌐 Deploy to Vercel

### Option A — Vercel CLI

```bash
npm i -g vercel
vercel
```

### Option B — GitHub Integration (Recommended)

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) → **Add New Project**
3. Import your GitHub repo
4. Framework Preset: **Other**
5. Click **Deploy** — done ✓

Vercel auto-deploys on every `git push`.

## 📝 License

MIT
